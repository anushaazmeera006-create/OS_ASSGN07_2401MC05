#include "kernel/types.h"
#include "kernel/riscv.h"
#include "user/user.h"

#define NTHREADS 3
#define ITERATIONS 100000

// Q1: all cloned threads see this one shared global variable.
volatile int counter = 0;

// Each clone() call receives its own page-aligned, one-page user stack.
char stacks[NTHREADS][PGSIZE] __attribute__((aligned(PGSIZE)));

void
worker(void *arg)
{
  int id = (int)(uint64)arg;
  int i;

  // Deliberately unsynchronized: Q2 will protect this critical section.
  for (i = 0; i < ITERATIONS; i++)
    counter++;

  printf("thread %d finished\n", id);

  // A thread must call exit() when its function finishes.
  exit(0);
}

int
main(void)
{
  int i;

  printf("threadtest: creating %d threads\n", NTHREADS);

  for (i = 0; i < NTHREADS; i++) {
    if (clone(worker, (void *)(uint64)(i + 1), stacks[i]) < 0) {
      printf("threadtest: clone failed\n");
      exit(1);
    }
  }

  for (i = 0; i < NTHREADS; i++) {
    if (join() < 0) {
      printf("threadtest: join failed\n");
      exit(1);
    }
  }

  printf("threadtest: counter = %d; expected %d\n",
         counter, NTHREADS * ITERATIONS);
  printf("threadtest: a value below %d demonstrates the Q1 race condition\n",
         NTHREADS * ITERATIONS);
  exit(0);
}
