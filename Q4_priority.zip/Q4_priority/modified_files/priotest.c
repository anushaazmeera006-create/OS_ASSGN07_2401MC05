
 // Q4: Test priority scheduling and aging.
#include "kernel/types.h"
#include "user/user.h"

volatile int order = 0;

int
main(void)
{
  int lowpid, highpid;
  int lowpriority = 20;
  int highpriority = 2;

  printf("Q4: Priority Scheduling and Aging Test\n");

  // Q4: Verify priority system calls.
  if (get_priority(getpid()) != 10 ||
      set_priority(getpid(), 5) < 0 ||
      get_priority(getpid()) != 5) {
    printf("FAIL: priority system calls\n");
    exit(1);
  }
  printf("PASS: priority system calls\n");

  // Q4: Create two workers with different priorities.
  lowpid = fork();
  if (lowpid == 0) {
    set_priority(getpid(), lowpriority);
    for (volatile int i = 0; i < 3000000; i++)
      ;
    printf("Low-priority worker finished\n");
    exit(0);
  }

  highpid = fork();
  if (highpid == 0) {
    set_priority(getpid(), highpriority);
    for (volatile int i = 0; i < 3000000; i++)
      ;
    printf("High-priority worker finished\n");
    exit(0);
  }

  if (lowpid > 0 && highpid > 0) {
    wait(0);
    wait(0);
  }

  // Q4: Show aging changes in a low-priority process.
  printf("Aging test: waiting process starts at priority %d\n",
         lowpriority);
  printf("Aging policy: after 30 scheduler scans, priority improves by 1\n");
  printf("Inspect kernel/proc.c scheduler output to observe actual aging.\n");

  printf("Q4 test completed.\n");
  exit(0);
}

